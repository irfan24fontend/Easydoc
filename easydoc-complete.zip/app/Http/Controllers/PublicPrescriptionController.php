<?php

namespace App\Http\Controllers;

use App\Models\Prescription;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Schema;

class PublicPrescriptionController extends Controller
{
    /** Print blade er possible path - apnar projecte jeta ache seta auto-detect hobe */
    private const VIEWS = [
        'doctor.prescriptions.print', 'doctor.prescription.print',
        'doctor.prescriptions.show_print', 'prescriptions.print', 'prescription.print',
    ];

    public function show(string $token)
    {
        $prescription = Prescription::where('share_token', $token)->firstOrFail();

        foreach (['doctor', 'patient', 'medicines', 'chamber', 'items', 'doctor.user'] as $rel) {
            $base = explode('.', $rel)[0];
            if (method_exists($prescription, $base)) {
                try { $prescription->loadMissing($rel); } catch (\Throwable $e) {}
            }
        }

        $view = collect(self::VIEWS)->first(fn ($v) => view()->exists($v));
        abort_unless($view, 500, 'Print view khuje paoa jayni. PublicPrescriptionController::VIEWS e nam din.');

        $data = [
            'prescription' => $prescription,
            'isPublic'     => true,
            'doctor'       => $prescription->doctor ?? null,
            'patient'      => $prescription->patient ?? null,
            'chamber'      => $prescription->chamber ?? null,
        ];

        return response()->view($view, $data)
            ->header('X-Robots-Tag', 'noindex, nofollow, noarchive')
            ->header('Referrer-Policy', 'no-referrer');
    }

    public function revoke(Request $request, $id)
    {
        $p = Prescription::findOrFail($id);

        $user = $request->user();
        $allowed = [$user->id];
        if (method_exists($user, 'doctor') && $user->doctor) {
            $allowed[] = $user->doctor->id;
        }
        abort_unless(in_array($p->doctor_id ?? null, $allowed, true) || ($user->role ?? '') === 'admin', 403);

        $p->forceFill(['share_token' => null, 'shared_at' => null])->save();

        return back()->with('success', 'Share link bondho kora hoyeche.');
    }
}
