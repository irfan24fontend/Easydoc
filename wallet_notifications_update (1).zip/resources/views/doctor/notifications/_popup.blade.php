{{--
    Pop-up + sound for new notifications (Super Admin broadcasts, recharge approved/rejected, ...).
    Included once at the bottom of layouts/doctor.blade.php.

    - Checks the server every 30 seconds (and once when the page opens).
    - A new notification shows a card with OK / View. It stays until the doctor presses OK,
      and disappears by itself after 10 seconds (it stays in the notification list as unread).
    - A short two-tone chime plays with each pop-up (the browser allows sound after the first click/tap on the page).
--}}
@php $__popupDoctor = auth()->user()?->doctor; @endphp

@if ($__popupDoctor && $__popupDoctor->isApproved())
<div id="edPopStack" aria-live="assertive"></div>

<style>
    #edPopStack { position:fixed; top:76px; right:20px; z-index:2100; display:flex; flex-direction:column; gap:12px; width:min(380px, calc(100vw - 24px)); pointer-events:none; }
    .ed-pop { pointer-events:auto; background:#fff; border:1px solid #e5e9f0; border-left:5px solid #4f46e5; border-radius:16px; box-shadow:0 18px 44px rgba(15,23,42,.24); padding:14px 16px 0; overflow:hidden; animation:edPopIn .28s ease-out both; font-family:'Inter',system-ui,sans-serif; }
    .ed-pop.out { animation:edPopOut .25s ease-in both; }
    .ed-pop[data-type="feature"] { border-left-color:#7c3aed; }
    .ed-pop[data-type="news"] { border-left-color:#0ea5e9; }
    .ed-pop[data-type="recharge"] { border-left-color:#10b981; }
    .ed-pop[data-type="notice"] { border-left-color:#f59e0b; }
    .ed-pop-top { display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:6px; }
    .ed-pop-label { font-size:11px; font-weight:800; letter-spacing:.06em; text-transform:uppercase; color:#4f46e5; display:flex; align-items:center; gap:6px; }
    .ed-pop-secs { font-size:11px; color:#94a3b8; font-weight:600; }
    .ed-pop-title { font-size:15px; font-weight:800; color:#0f172a; line-height:1.3; }
    .ed-pop-body { font-size:13px; color:#475569; margin-top:4px; line-height:1.5; overflow-wrap:anywhere; }
    .ed-pop-actions { display:flex; gap:8px; margin:12px 0 12px; }
    .ed-pop-actions button, .ed-pop-actions a { font:700 13px 'Inter',sans-serif; border-radius:10px; padding:8px 18px; text-decoration:none; cursor:pointer; border:1px solid transparent; }
    .ed-pop-actions .ok { background:#4f46e5; color:#fff; }
    .ed-pop-actions .ok:hover { background:#4338ca; }
    .ed-pop-actions .view { background:#fff; color:#334155; border-color:#e2e8f0; }
    .ed-pop-bar { height:4px; background:#eef2ff; margin:0 -16px; }
    .ed-pop-bar i { display:block; height:100%; width:100%; background:#4f46e5; transform-origin:left; animation:edPopBar 10s linear forwards; }
    @keyframes edPopIn { from { opacity:0; transform:translateX(24px); } to { opacity:1; transform:none; } }
    @keyframes edPopOut { to { opacity:0; transform:translateX(24px); } }
    @keyframes edPopBar { to { transform:scaleX(0); } }
    @media (max-width: 575px) { #edPopStack { top:64px; right:12px; left:12px; width:auto; } }
    @media (prefers-reduced-motion: reduce) { .ed-pop, .ed-pop.out { animation:none; } }
</style>

<script>
(function () {
    var POLL_URL = @json(route('doctor.notifications.poll'));
    var READ_URL = @json(route('doctor.notifications.read', ['notification' => '__ID__']));
    var CSRF = @json(csrf_token());
    var VISIBLE_MS = 10000;
    var SOUND_KEY = 'easydoc.notifySound';

    var stack = document.getElementById('edPopStack');
    var queue = [], showing = false;

    /* ---------- sound (generated in the browser, no audio file needed) ---------- */
    var audioCtx = null, soundWaiting = false;

    function soundEnabled() { try { return localStorage.getItem(SOUND_KEY) !== 'off'; } catch (e) { return true; } }
    function getCtx() {
        if (!audioCtx) {
            var AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return null;
            audioCtx = new AC();
        }
        return audioCtx;
    }
    function playTones(c) {
        var now = c.currentTime;
        [[880, 0], [1175, 0.16]].forEach(function (n) {
            var o = c.createOscillator(), g = c.createGain();
            o.type = 'sine'; o.frequency.value = n[0];
            g.gain.setValueAtTime(0.0001, now + n[1]);
            g.gain.exponentialRampToValueAtTime(0.22, now + n[1] + 0.03);
            g.gain.exponentialRampToValueAtTime(0.0001, now + n[1] + 0.42);
            o.connect(g); g.connect(c.destination);
            o.start(now + n[1]); o.stop(now + n[1] + 0.45);
        });
    }
    function chime() {
        if (!soundEnabled()) return;
        var c = getCtx(); if (!c) return;
        if (c.state === 'running') { playTones(c); return; }
        // Browsers keep sound locked until the person clicks or taps once on the page
        soundWaiting = true;
        try { c.resume(); } catch (e) {}
    }
    function unlock() {
        var c = getCtx(); if (!c) return;
        var go = function () { if (soundWaiting) { soundWaiting = false; playTones(c); } };
        if (c.state === 'running') go(); else c.resume().then(go).catch(function () {});
    }
    ['click', 'keydown', 'touchstart'].forEach(function (ev) { document.addEventListener(ev, unlock, { passive: true }); });

    /* ---------- pop-up cards ---------- */
    function markRead(id) {
        fetch(READ_URL.replace('__ID__', id), {
            method: 'POST', credentials: 'same-origin',
            headers: { 'X-CSRF-TOKEN': CSRF, 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' }
        }).then(poll).catch(function () {});
    }

    function show(n) {
        showing = true;
        chime();

        var el = document.createElement('div');
        el.className = 'ed-pop'; el.setAttribute('role', 'alert'); el.setAttribute('data-type', n.type || 'notice');

        var top = document.createElement('div'); top.className = 'ed-pop-top';
        var label = document.createElement('span'); label.className = 'ed-pop-label';
        label.textContent = n.label || 'Notification';
        var secs = document.createElement('span'); secs.className = 'ed-pop-secs'; secs.textContent = '10s';
        top.appendChild(label); top.appendChild(secs);

        var title = document.createElement('div'); title.className = 'ed-pop-title'; title.textContent = n.title;
        var body = document.createElement('div'); body.className = 'ed-pop-body'; body.textContent = n.body;

        var actions = document.createElement('div'); actions.className = 'ed-pop-actions';
        var ok = document.createElement('button'); ok.type = 'button'; ok.className = 'ok'; ok.textContent = 'OK';
        var view = document.createElement('a'); view.className = 'view'; view.href = n.url; view.textContent = 'View';
        actions.appendChild(ok); actions.appendChild(view);

        var bar = document.createElement('div'); bar.className = 'ed-pop-bar'; bar.appendChild(document.createElement('i'));

        [top, title, body, actions, bar].forEach(function (p) { el.appendChild(p); });
        stack.appendChild(el);

        var left = VISIBLE_MS / 1000, ticker = setInterval(function () { left--; if (left >= 0) secs.textContent = left + 's'; }, 1000);
        var timer = setTimeout(function () { close(false); }, VISIBLE_MS);
        var closed = false;

        function close(pressedOk) {
            if (closed) return; closed = true;
            clearTimeout(timer); clearInterval(ticker);
            if (pressedOk) markRead(n.id);
            el.classList.add('out');
            setTimeout(function () { el.remove(); showing = false; next(); }, 250);
        }
        ok.addEventListener('click', function () { close(true); });
    }

    function next() {
        if (showing || !queue.length) return;
        show(queue.shift());
    }

    /* ---------- polling ---------- */
    function setBadge(count) {
        document.querySelectorAll('.js-notif-count').forEach(function (b) {
            b.textContent = count > 99 ? '99+' : count;
            b.style.display = count > 0 ? '' : 'none';
        });
    }

    function poll() {
        fetch(POLL_URL, { credentials: 'same-origin', headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' } })
            .then(function (r) { return r.ok ? r.json() : null; })
            .then(function (d) {
                if (!d) return;
                setBadge(d.unread || 0);
                (d.items || []).forEach(function (n) { queue.push(n); });
                next();
            })
            .catch(function () {});
    }

    poll();
    setInterval(function () { if (!document.hidden) poll(); }, 30000);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) poll(); });
})();
</script>
@endif
