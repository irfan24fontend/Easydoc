<?php

namespace App\Http\Controllers\Doctor;

use App\Http\Controllers\Controller;
use App\Models\Announcement;
use App\Models\Doctor;
use App\Models\DoctorNotification;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class NotificationController extends Controller
{
    protected function doctor(): Doctor
    {
        return auth()->user()->doctor;
    }

    /** My notification list. */
    public function index(): View
    {
        $doctor = $this->doctor();

        $notifications = DoctorNotification::where('doctor_id', $doctor->id)
            ->orderByDesc('id')
            ->paginate(15);

        $unread = DoctorNotification::where('doctor_id', $doctor->id)->unread()->count();

        return view('doctor.notifications.index', compact('notifications', 'unread'));
    }

    /** News: everything the Super Admin has broadcast. */
    public function news(): View
    {
        $items = Announcement::latest()->paginate(10);

        return view('doctor.notifications.news', compact('items'));
    }

    /**
     * Polled by the browser every ~30 seconds.
     * Returns notifications whose pop-up has not been shown yet (each is delivered once).
     */
    public function poll(): JsonResponse
    {
        $doctor = $this->doctor();

        $fresh = DoctorNotification::where('doctor_id', $doctor->id)
            ->whereNull('popup_at')
            ->orderBy('id')
            ->limit(5)
            ->get();

        if ($fresh->isNotEmpty()) {
            DoctorNotification::whereIn('id', $fresh->pluck('id'))->update(['popup_at' => now()]);
        }

        return response()->json([
            'unread' => DoctorNotification::where('doctor_id', $doctor->id)->unread()->count(),
            'items'  => $fresh->map(fn (DoctorNotification $n) => [
                'id'    => $n->id,
                'type'  => $n->type,
                'label' => $n->typeLabel(),
                'title' => $n->title,
                'body'  => \Illuminate\Support\Str::limit($n->body, 160),
                'url'   => route('doctor.notifications.open', $n->id),
            ])->values(),
        ]);
    }

    /** Mark one as read, then go to its link (or back to the list). */
    public function open(DoctorNotification $notification): RedirectResponse
    {
        $this->authorizeRow($notification);

        if (! $notification->isRead()) {
            $notification->update(['read_at' => now()]);
        }

        return $notification->link_url
            ? redirect()->away($notification->link_url)
            : redirect()->route('doctor.notifications.index');
    }

    public function markRead(DoctorNotification $notification): JsonResponse|RedirectResponse
    {
        $this->authorizeRow($notification);

        if (! $notification->isRead()) {
            $notification->update(['read_at' => now()]);
        }

        return request()->expectsJson()
            ? response()->json(['ok' => true])
            : back();
    }

    public function markAllRead(): RedirectResponse
    {
        DoctorNotification::where('doctor_id', $this->doctor()->id)
            ->unread()
            ->update(['read_at' => now()]);

        return back()->with('success', 'All notifications marked as read.');
    }

    protected function authorizeRow(DoctorNotification $notification): void
    {
        abort_unless($notification->doctor_id === $this->doctor()->id, 404);
    }
}
